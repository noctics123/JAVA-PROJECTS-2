
package util;

public class prueba1 {

    public static void main(String[] args) {
        MySQLConexion.getConexion();
    }

}
