

package controlador;

import modelo.*;



public class NewClass {
    
    public static void main(String[] args) {
//        Marca x=new Marca("", "ASD");
//        MarcaDAO obj=new MarcaDAO();
//        obj.adicionaM(x);
//        Producto x=new Producto("", "M001", "T001","asd", 15, 15);
//        ProductoDAO obj=new ProductoDAO();
//        obj.adicionaP(x);
//        Empleado x=new Empleado("", "EDWIN", "COLINA", 76318886, 930473064, "EDWIN@GAIL.COM", "C003", "edwin", "z5a4s69");
//        EmpleadoDAO obj=new EmpleadoDAO();
//        obj.adicionaEp(x);
        
    }
 
}
