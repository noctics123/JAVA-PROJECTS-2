
package Interface;

import java.util.*;
import modelo.Tipo;

public interface ITipo {
    List<Tipo> listadoT();
}
