
package Interface;

import java.util.*;
import modelo.*;

public interface ICargo {
    List<Cargo> listadoCa();
}
