
package modelo;

public class Tipo {
    private String codt;
    private String tipo;

    public String getCodt() {
        return codt;
    }

    public void setCodt(String codt) {
        this.codt = codt;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
}
