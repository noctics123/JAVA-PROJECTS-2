
package modelo;

public class Marca {
    private String codm;
    private String marca;

    public String getCodm() {
        return codm;
    }

    public void setCodm(String codm) {
        this.codm = codm;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    
}
